<?php
class UAEPassAPI
{
    private $api_endpoints = [
        'production' => [
            'authorization' => 'https://id.uaepass.ae/idshub/authorize',
            'token' => 'https://id.uaepass.ae/idshub/token',
            'user_info' => 'https://id.uaepass.ae/idshub/userinfo',
            'logout' => 'https://id.uaepass.ae/idshub/logout',
        ],
        'staging' => [
            'authorization' => 'https://stg-id.uaepass.ae/idshub/authorize',
            'token' => 'https://stg-id.uaepass.ae/idshub/token',
            'user_info' => 'https://stg-id.uaepass.ae/idshub/userinfo',
            'logout' => 'https://stg-id.uaepass.ae/idshub/logout',
        ],
    ];

    private $allowed_environments = ['production', 'staging'];

    private $api_environment;

    public function __construct()
    {
        $options = get_option('uae_pass_options');

        $this->api_environment = isset($options['api_environment']) && in_array($options['api_environment'], $this->allowed_environments) ? $options['api_environment'] : 'production';
    }

    public function set_environment($api_environment)
    {
        if (in_array($api_environment, $this->allowed_environments)) {
            $this->api_environment = $api_environment;
        } else {
            // Handle invalid environment error
            // For example, throw an exception or log the error
        }
    }

    private function get_current_environment()
    {
        return $this->api_environment;
    }

    public function get_authorization_endpoint()
    {
        $current_environment = $this->get_current_environment();
        return $this->api_endpoints[$current_environment]['authorization'];
    }

    public function get_token_endpoint()
    {
        $current_environment = $this->get_current_environment();
        return $this->api_endpoints[$current_environment]['token'];
    }

    public function get_user_info_endpoint()
    {
        $current_environment = $this->get_current_environment();
        return $this->api_endpoints[$current_environment]['user_info'];
    }

    public function get_logout_endpoint()
    {
        $current_environment = $this->get_current_environment();
        return $this->api_endpoints[$current_environment]['logout'];
    }
}

// Example usage:
$uaepass_api = new UAEPassAPI();


