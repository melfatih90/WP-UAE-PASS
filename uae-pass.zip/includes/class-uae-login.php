<?php
class UAE_Login
{
    public function add_custom_login_button()
    {

        $current_locale = get_locale();

        $options = get_option('uae_pass_options');
        if (strtolower($current_locale) === 'ar') {
            $path = plugins_url('../public/images/Arabic/AR_UAEPASS_', __FILE__);
        } else {
            $path = plugins_url('../public/images/English/UAEPASS_', __FILE__);
        }

        $selected_image = isset($options['login_image']) ? $options['login_image'] : '';

        $client = isset($options['client']) ? $options['client'] : '';
        $scope = isset($options['scope']) ? $options['scope'] : '';
        $callback_url = isset($options['callback_url']) ? $options['callback_url'] : 'uae-pass-callback';

        $callback = home_url() . "/" . $callback_url;

        $state = bin2hex(random_bytes(32)); // 32 characters long
        $_SESSION['uae_pass_state'] = $state;

        $uaepass_api = new UAEPassAPI(); // Assuming UAEPassAPI is already included and available
        $authorization_endpoint = $uaepass_api->get_authorization_endpoint();

        $_SESSION['nonce'] = wp_create_nonce('uae_pass_verify');
        $authorization_endpoint = $authorization_endpoint . "?response_type=code&client_id=" . $client . "&redirect_uri=" . $callback . "&scope=" . $scope . "&state=" . $state;

        $_SESSION['current_url'] = $this->get_current_url();
        echo '<a href="' . esc_url($authorization_endpoint) . '">';
        echo '<img src="' . esc_url($path . $selected_image) . '" class="custom-login-image" alt="Login" style="width: 275px; height: auto;">';
        echo '</a>';

    }

    private function get_current_url()
    {
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
        $domainName = $_SERVER['HTTP_HOST'];
        $requestUri = $_SERVER['REQUEST_URI'];
        $url = $protocol . $domainName . $requestUri;
        return $url;
    }

}
