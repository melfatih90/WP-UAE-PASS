<?php
class UAE_Pass_Callback
{
    public function __construct()
    {
        // Register the callback handler
        add_action('init', array($this, 'register_callback_handler'));
        add_filter('shake_error_codes', array($this, 'my_custom_shake_error_codes'));
        // Parse the query variable to trigger the callback handler
        add_action('parse_request', array($this, 'parse_callback_request'));
        add_filter('login_message', array($this, 'add_login_error_message'));
    }
    public function add_login_error_message($message)
    {
        // Check if there's a 'login_error' in the query string
        if ($login_error = isset($_GET['login_error']) ? $_GET['login_error'] : null) {
            // Define custom error messages based on the error code
            $error_messages = [
                'nonce_failure' => esc_html__('Nonce verification failed, possible CSRF attack.', 'uae-pass'),
                'state_mismatch' => esc_html__('State mismatch, possible CSRF attack.', 'uae-pass'),
                'api_error' => esc_html__('There was an error communicating with the UAE Pass', 'uae-pass'),
            ];
            // Get the error message based on the error code, default to a generic error message
            $error_message = isset($error_messages[$login_error]) ? $error_messages[$login_error] : esc_html__('An unknown error occurred.', 'uae-pass');

            // Optionally, include a more specific error message if 'error_message' is in the query string
            if ($detailed_error = isset($_GET['error_message']) ? $_GET['error_message'] : null) {
                $error_message .= ' ' . esc_html($detailed_error);
            }
            // Format the error message to be displayed above the login form
            $formatted_message = '<div class="notice notice-error"><p>Error :' . $error_message . '</p></div>';
            // Append the custom error message to any existing messages
            add_action('login_footer', 'wp_shake_js', 30);
            $message .= $formatted_message;
        }

        return $message;
    }

    public function my_custom_shake_error_codes($error_codes)
    {
        // Add custom error codes
        $error_codes[] = 'nonce_failure';
        $error_codes[] = 'state_mismatch';
        $error_codes[] = 'api_error';

        return $error_codes;
    }

    public function uae_pass_callback_handler()
    {

        if (isset($_GET['code'], $_GET['state'])) {

            // Verify the nonce
            $_REQUEST['_wpnonce'] = $_SESSION['nonce'] ?? '';
            if (!wp_verify_nonce($_REQUEST['_wpnonce'], 'uae_pass_verify')) {
                // Nonce verification failed, handle the error
                wp_die(esc_html__('Nonce verification failed, possible CSRF attack.', 'uae-pass'));
            }

            $storedState = $_SESSION['uae_pass_state'] ?? '';

            if ($_GET['state'] !== $storedState) {
                $this->call_uapass_userinfo_redirect();
            }
            $access_token = $this->call_uapass_token_api($_GET['code']);
            $userData = $this->call_uapass_userinfo_api($access_token);
            $this->handle_uapass_userinfo_response($userData);
            exit;
        } else {
            if (isset($_REQUEST['error'])) {
                $this->call_uapass_userinfo_redirect();

                exit;
            }
        }
    }

    public function register_callback_handler()
    {
        $options = get_option('uae_pass_options');
        $callback_url = isset($options['callback_url']) ? $options['callback_url'] : 'uae-pass-callback';
        add_rewrite_endpoint($callback_url, EP_ROOT);
    }

    public function parse_callback_request()
    {
        global $wp;
        $options = get_option('uae_pass_options');
        $callback_url = isset($options['callback_url']) ? $options['callback_url'] : 'uae-pass-callback';

        if (isset($wp->query_vars[$callback_url])) {
            $this->uae_pass_callback_handler();
        }
    }

    protected function call_uapass_token_api($code)
    {
        $uaepass_api = new UAEPassAPI();
        $token_endpoint = $uaepass_api->get_token_endpoint();
        $options = get_option('uae_pass_options');
        $callback_url = isset($options['callback_url']) ? $options['callback_url'] : 'uae-pass-callback';
        $callback = home_url() . "/" . $callback_url . "&code=" . $code;

        $response = wp_remote_post($token_endpoint . "?grant_type=authorization_code&redirect_uri=" . $callback, array(
            'headers' => array(
                'Authorization' => 'Basic ' . $options['secret'],
            ),
        ));

        if (is_wp_error($response)) {
            $login_url = wp_login_url();
            $redirect_url = add_query_arg('login_error', 'api_error', $login_url);
            wp_safe_redirect($redirect_url);

        }

        $body = wp_remote_retrieve_body($response);
        $json_response = json_decode($body, true);

        if (isset($json_response['error'])) {

            $login_url = wp_login_url();
            $redirect_url = add_query_arg('login_error', 'api_error', $login_url);
            wp_safe_redirect($redirect_url);

            exit;

        }

        if (isset($json_response['access_token'])) {
            return $json_response['access_token'];
        }
    }

    protected function call_uapass_userinfo_redirect($access_token = null)
    {
        $referrer = $_SESSION['current_url'] ?? '';
        // Check if the referrer is the "My Account" page

        $redirect_url = add_query_arg('login_error', 'api_error', $referrer);

        wp_safe_redirect($redirect_url);
        exit;

    }
    protected function call_uapass_userinfo_api($access_token)
    {
        $uaepass_api = new UAEPassAPI();
        $userinfo_endpoint = $uaepass_api->get_user_info_endpoint();

        $response = wp_remote_get($userinfo_endpoint, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $access_token,
            ),
        ));

        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            return $error_message;
        }

        $body = wp_remote_retrieve_body($response);
        $json_response = json_decode($body, true);

        if (isset($json_response['error'])) {

            $this->call_uapass_userinfo_redirect();

        }

        return $body; // Assuming the rest of the function processes this response
    }

    protected function handle_uapass_userinfo_response($userinfo_response)
    {
// Parse the JSON response
        $userinfo_data = json_decode($userinfo_response, true);

// Extract relevant user information
        $email = sanitize_email($userinfo_data['email']);
        $first_name_ar = sanitize_text_field($userinfo_data['firstnameAR' ?? '']);
        $last_name_ar = sanitize_text_field($userinfo_data['lastnameAR'] ?? '');
        $first_name_en = sanitize_text_field($userinfo_data['firstnameEN'] ?? '');
        $last_name_en = sanitize_text_field($userinfo_data['lastnameEN'] ?? '');

// Check if user already exists
        $user = get_user_by('email', $email);

        if ($user) {
            // User exists, update their information
            $user_id = wp_update_user(array(
                'ID' => $user->ID,
                'first_name' => $first_name_en,
                'last_name' => $last_name_en,
            ));
        } else {
            // User does not exist, create new user
            $user_id = wp_insert_user(array(
                'user_login' => $email, // Use email as username
                'user_email' => $email,
                'first_name' => $first_name_en,
                'last_name' => $last_name_en,
                'role' => 'subscriber', // Assign role as needed
            ));
        }

        if (!is_wp_error($user_id)) {
            // Log in the user
            wp_set_current_user($user_id);
            wp_set_auth_cookie($user_id);
            do_action('wp_login', $user, $email); // Trigger login hooks

            // Redirect user to some page after successful login
            wp_redirect(home_url('/dashboard')); // Change '/dashboard' to desired destination
            exit;
        } else {
            // Error occurred while creating or updating user
            wp_die('Error: Unable to create or update user.');
        }

    }
}

// Initialize the class
$uae_pass_callback = new UAE_Pass_Callback();
