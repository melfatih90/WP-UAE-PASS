document.addEventListener('DOMContentLoaded', function() {
    var urlParams = new URLSearchParams(window.location.search);
    var loginError = urlParams.get('login_error');
    var errorMessage = urlParams.get('error_message');

    if (loginError) {
        Swal.fire({
            title: 'Authentication Failed!',
            text: errorMessage || 'Please try again.',
            icon: 'error',
            confirmButtonText: 'OK'
        });
    }
});
