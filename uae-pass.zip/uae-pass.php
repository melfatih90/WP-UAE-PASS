<?php
/**
 * Plugin Name: UAE Pass Integration
 * Plugin URI: https: //scripto-tech.com/portfolio/uae-pass-integration-with-wordpress/
 * Description: The UAE Pass Plugin simplifies the process of integrating UAE Pass authentication into WordPress websites. With this plugin, users can leverage their UAE Pass credentials to log in securely, providing a seamless and convenient login experience. The plugin offers customizable settings to configure various aspects of UAE Pass authentication, including client ID, scope, callback URL, and login button appearance. Whether your website serves an Arabic or English-speaking audience, the plugin adapts to the user's language preference, enhancing accessibility. UAE Pass authentication offers a robust security mechanism, ensuring that user data remains protected throughout the login process. By leveraging this trusted authentication solution, WordPress website owners can enhance security and user experience simultaneously.
 * Version: 1.0
 * Author: Mohammed Elfatih
 * Author URI: http://scripto-tech.com
 * License: GPL2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

// Include the settings page code
require_once plugin_dir_path(__FILE__) . 'admin/settings-page.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-uae-pass-api.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-uae-pass-callback.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-uae-login.php';

// Instantiate UAE_Login class
$uae_login = new UAE_Login();

// Add login button to the login form
add_action('login_form', array($uae_login, 'add_custom_login_button'));


function uae_pass_load_textdomain()
{
    load_plugin_textdomain('uae-pass', false, basename(dirname(__FILE__)) . '/languages/');
}
add_action('plugins_loaded', 'uae_pass_load_textdomain');



