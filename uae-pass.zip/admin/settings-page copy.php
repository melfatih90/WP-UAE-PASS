<?php
// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

class UAE_Pass_Settings
{
    public function __construct()
    {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_init', array($this, 'flush_rewrite_rules'));
    }

    public function add_admin_menu()
    {
        add_menu_page(
            esc_html__('UAE Pass Settings', 'uae-pass'),
            esc_html__('UAE Pass', 'uae-pass'),
            'manage_options',
            'uae-pass',
            array($this, 'settings_page'),
            plugins_url('../public/images/icons/uae_pass_plugin_icon_20x20.png', __FILE__),
            6
        );
    }

    public function register_settings()
    {
        register_setting('uae_pass_options_group', 'uae_pass_options', array($this, 'sanitize_settings'));

        add_settings_section(
            'uae_pass_main_section',
            esc_html__('UAE PASS Settings', 'uae-pass'),
            array($this, 'section_text'),
            'uae-pass'
        );

        $this->add_setting_field('api_environment', 'API Environment', 'Select the API environment (production or staging).');
        $this->add_setting_field('client', 'Client', 'Enter your client ID for UAE Pass authentication. Identifier of the client application. (To be shared by UAEPASS Team)');
        $this->add_setting_field('secret', 'Secret', 'Enter your client secret for UAE Pass authentication.');
        $this->add_setting_field('scope', 'Scope', 'Define the scope for UAE Pass...');
        $this->add_setting_field('callback_url', 'Callback URL', 'Customize the callback URL. Redirect URI to the WordPress application. You can customize but make sure to share with UAE PASS for approval');
        $this->add_setting_field('login_image', 'Login Button', 'Select the login button for UAE Pass authentication.', 'login_image_render');
    }

    private function add_setting_field($id, $title, $description, $render_callback = 'render_input_field')
    {
        add_settings_field(
            "uae_pass_{$id}",
            esc_html($title, 'uae-pass'),
            array($this, $render_callback),
            'uae-pass',
            'uae_pass_main_section',
            array(
                'id' => $id,
                'description' => $description
            )
        );
    }

    public function sanitize_settings($input)
    {
        $new_input = [];
        foreach ($input as $key => $value) {
            $new_input[$key] = sanitize_text_field($value);
        }
        return $new_input;
    }

    public function section_text()
    {
        echo '<div style="position: relative;">';
        echo '<p>' . esc_html__('The UAE Pass Plugin simplifies the process of integrating UAE Pass authentication into WordPress websites.', 'uae-pass') . '</p>';
        echo '</div>';
    }

public function render_input_field($args)
{
    $options = get_option('uae_pass_options');
    $value = isset($options[$args['id']]) ? $options[$args['id']] : '';

    // Directly use esc_attr() for attributes in the HTML output
    echo "<input id='" . esc_attr('uae_pass_' . $args['id']) . "' name='" . esc_attr('uae_pass_options[' . $args['id'] . ']') . "' size='40' type='text' value='" . esc_attr($value) . "' />";

    if (!empty($args['description'])) {
        // Use esc_html() to escape and display the description text
        echo "<p class='description'>" . esc_html($args['description']) . "</p>";
    }
}

    public function login_image_render($args)
    {
        // Your implementation for rendering login image selection
        // Ensure to use esc_attr(), esc_url(), etc. for safe output
    }

    public function settings_page()
    {
        ?>
        <div class="wrap">
            <h2><?php echo esc_html__('UAE Pass Settings', 'uae-pass'); ?></h2>
            <form action="options.php" method="post">
                <?php
                settings_fields('uae_pass_options_group');
                do_settings_sections('uae-pass');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function flush_rewrite_rules()
    {
        flush_rewrite_rules();
    }
}

new UAE_Pass_Settings();
