<?php
// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

class UAE_Pass_Settings
{
    public function __construct()
    {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_init', array($this, 'flush_rewrite_rules'));
    }

    public function add_admin_menu()
    {
        add_menu_page(
            __('UAE Pass Settings', 'uae-pass'), // Page title
            __('UAE Pass', 'uae-pass'), // Menu title
            'manage_options', // Capability
            'uae-pass', // Menu slug
            array($this, 'settings_page'), // Callback function to render the settings page
            plugins_url('../public/images/icons/uae_pass_plugin_icon_20x20.png', __FILE__), // Icon URL
            6// Position
        );
    }

    public function register_settings()
    {
        register_setting('uae_pass_options_group', 'uae_pass_options', array($this, 'sanitize_settings'));

        add_settings_section(
            'uae_pass_main_section',
            __('UAE PASS Settings', 'uae-pass'), // Section title
            array($this, 'section_text'), // Callback function to render section text
            'uae-pass'
        );
        // Add individual settings fields with descriptions
        add_settings_field('uae_pass_api_environment', __('API Environment', 'uae-pass'), array($this, 'api_environment_input'), 'uae-pass', 'uae_pass_main_section', array('description' => __('Select the API environment (production or staging).', 'uae-pass')));
        add_settings_field('uae_pass_client', __('Client', 'uae-pass'), array($this, 'client_input'), 'uae-pass', 'uae_pass_main_section', array('description' => __('Enter your client ID for UAE Pass authentication. Identifier of the client application. (To be shared by UAEPASS Team)', 'uae-pass')));
        add_settings_field('uae_pass_secret', __('Secret', 'uae-pass'), array($this, 'secret_input'), 'uae-pass', 'uae_pass_main_section', array('description' => __('Enter your client secret for UAE Pass authentication.', 'uae-pass')));
        add_settings_field('uae_pass_scope', __('Scope', 'uae-pass'), array($this, 'scope_input'), 'uae-pass', 'uae_pass_main_section', array('description' => __('Define the scope for UAE Pass ,List of values, separated by spaces, that represent the scope of the authorization that the application wants to obtain. It queries the scopes required for accessing the resources or services in question. (To be shared by UAEPASS Team if its value is other than specified in sample above)', 'uae-pass')));
        add_settings_field('uae_pass_callback_url', __('Callback URL', 'uae-pass'), array($this, 'callback_url_input'), 'uae-pass', 'uae_pass_main_section', array('description' => __('Customize the callback URL ,Redirect URI to the wordpress application. you can custom but make sure  share to UAE PASS for approvel', 'uae-pass')));
        add_settings_field('uae_pass_login_image', __('Login Button', 'uae-pass'), array($this, 'login_image_render'), 'uae-pass', 'uae_pass_main_section', array('description' => __('Select the button login Button for UAE Pass authentication.', 'uae-pass')));
    }

    public function sanitize_settings($input)
    {
        // Sanitize input fields here
        // Example: $sanitized_input = array_map('sanitize_text_field', $input);
        return $input;
    }

    public function section_text()
    {
        echo '<div style="position: relative;">'; // Adding a container for positioning
        echo '<p>' . __('The UAE Pass Plugin simplifies the process of integrating UAE Pass authentication into WordPress websites. With this plugin, users can leverage their UAE Pass credentials to log in securely, providing a seamless and convenient login experience.', 'uae-pass') . '</p>';
        echo '<p><h3>' . __('Please Update Below details are required:', 'uae-pass') . '</h3></p>';
        $image_url = plugins_url('../public/images/icons/icon_20x20.png', __FILE__);
        $current_locale = get_locale();
        if (strtolower($current_locale) === 'ar') {
            echo '<img src="' . $image_url . '" alt="Image" style="position: absolute; top: 0; left: 0; width: 250px; height: 250px;" />';

        }
        else
        {
        echo '<img src="' . $image_url . '" alt="Image" style="position: absolute; top: 0; right: 0; width: 250px; height: 250px;" />';

        }
        echo '</div>'; // Closing the container
    }

    public function client_input($args)
    {
        $options = get_option('uae_pass_options');
        ?>
        <input id="uae_pass_client" name="uae_pass_options[client]" size="40" type="text" value="<?php echo esc_attr($options['client']); ?>" />
        <p class="description"><?php echo $args['description']; ?></p>
        <?php
}

    public function secret_input($args)
    {
        $options = get_option('uae_pass_options');
        ?>
        <input id="uae_pass_secret" name="uae_pass_options[secret]" size="40" type="text" value="<?php echo esc_attr($options['secret']); ?>" />
        <p class="description"><?php echo $args['description']; ?></p>
        <?php
}

    public function scope_input($args)
    {
        $options = get_option('uae_pass_options');
        $scope = isset($options['scope']) ? $options['scope'] : 'urn:uae:digitalid:profile:general&acr_values=urn:safelayer:tws:policies:authentication:level:low';
        ?>
        <input id="uae_pass_scope" name="uae_pass_options[scope]" size="40" type="text" value="<?php echo esc_attr($scope); ?>" />
        <p class="description"><?php echo $args['description']; ?></p>
        <?php
}

    public function callback_url_input($args)
    {
        $options = get_option('uae_pass_options');
        $callback_url = isset($options['callback_url']) ? $options['callback_url'] : 'uae-pass-callback';
        ?>
        <input id="uae_pass_callback_url" name="uae_pass_options[callback_url]" size="40" type="text" value="<?php echo esc_attr($callback_url); ?>" />
        <p class="description"><?php echo $args['description']; ?></p>
        <?php
}

    public function api_environment_input($args)
    {
        $options = get_option('uae_pass_options');
        $selected_environment = isset($options['api_environment']) ? $options['api_environment'] : 'production'; // Default to production if not set
        ?>
        <select id="uae_pass_api_environment" name="uae_pass_options[api_environment]">
            <option value="production" <?php selected('production', $selected_environment);?>><?php _e('Production', 'uae-pass');?></option>
            <option value="staging" <?php selected('staging', $selected_environment);?>><?php _e('Staging', 'uae-pass');?></option>
        </select>
        <p class="description"><?php echo $args['description']; ?></p>
        <?php
}

    public function login_image_render($args)
    {
        $options = get_option('uae_pass_options');
        // Define your image filenames here
        $images = array(
            'Sign_in_Btn_Default_Black_Active.svg',
            'Sign_in_Btn_Default_White_Focus.svg',
            'Sign_in_Btn_Outline_Pill_White_Focus.svg',
            'Sign_in_Btn_Pill_Black_Focus.svg',
            'Sign_in_Btn_Pill_White_Focus.svg',
            'Sign_in_Btn_SharpCorners_White_Focus.svg',
        );

        ?>
        <p style="margin-bottom:10px"><?php echo $args['description']; ?></p>
        <?php
$current_locale = get_locale();

        if ($current_locale === 'ar') {
            $path = '/public/images/Arabic/AR_UAEPASS_';
        } else {
            $path = '/public/images/English/UAEPASS_';

            // Language is not Arabic
            // Your code for other languages here
        }

        foreach ($images as $image) {
            $image_url = plugins_url($path . $image, dirname(__FILE__));
            $checked = checked($options['login_image'], $image, false);
            ?>
            <div style="margin-bottom:10px;display: flex; align-items: center;">
                <label style="display: flex; align-items: center;">
                    <input type="radio" name="uae_pass_options[login_image]" value="<?php echo $image; ?>" <?php echo $checked; ?>>
                    <img src="<?php echo esc_url($image_url); ?>" style="width: auto; height: auto; margin-right: 10px;" alt="<?php echo basename($image); ?>">
                </label>
            </div>
            <?php
}
    }

    public function settings_page()
    {
        ?>
        <div class="wrap">
            <h2><?php _e('UAE Pass Settings', 'uae-pass');?></h2>
            <form action="options.php" method="post">
                <?php
        settings_fields('uae_pass_options_group');
        do_settings_sections('uae-pass');
        submit_button();
        ?>

                <?php $this->footer_content();?> <!-- Call the footer content function -->


            <!-- Footer content ends here -->

            </form>
        </div>
        <?php
}

    private function footer_content()
    {
        $year = gmdate('Y'); // Get the current year
        ?>
          <footer style="margin-top: 20px; padding-top: 10px; border-top: 1px solid #eee;">
           <p><?php _e('For more information and support about UAE PASS Service, visit UAE PASS', 'uae-pass');?><a href="https://docs.uaepass.ae/" target="_blank"><?php _e('support page.', 'uae-pass');?></a></p>
                <p style=""><?php _e('For more information and support for Plugin or bugs', 'uae-pass');?><a href="https://scripto-tech.com" target="_blank"><?php _e('our support page.', 'uae-pass');?></a></p>
                    <p style=""><?php _e('Plugin GitHub', 'uae-pass');?><a href="https://github.com/melfatih90/WP-UAE-PASS" target="_blank"><?php _e('our support page.', 'uae-pass');?></a></p>
                <p style="text-align: center;"><?php _e('Thank you for using UAE Pass Plugin', 'uae-pass');?></p>
         <p style="text-align: center;">&copy; <?php echo $year; ?> All rights reserved.</p>
    </footer>
    <?php
}

    public function flush_rewrite_rules()
    {
        flush_rewrite_rules();
    }
}

new UAE_Pass_Settings();
?>
